"""Canonical DDPM RL entrypoints."""
