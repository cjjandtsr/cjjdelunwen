"""Generic training-engine contracts."""
